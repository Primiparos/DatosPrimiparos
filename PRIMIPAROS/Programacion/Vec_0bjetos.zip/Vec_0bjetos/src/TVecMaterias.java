
public class TVecMaterias {
    private int Tam;
    private TMateria Vec[];
    
    public TVecMaterias(){
        Tam=0;
        Vec=null;
    }
public void setTam(int N){
    int i;
    Tam=N;
    if(N>0){
        Vec=new TMateria[N];
        for(i=0;i<N;i++){
            Vec[i]=new TMateria();
        }
    }
    else{
    Vec=null;
}   
}
public void  setMateria(int Pos, TMateria Mat){
    if(Pos>=0 && Pos<Tam){
    Vec[Pos]=Mat;    
    }
}
public int getTam(){
    return Tam;
    
}
public TMateria  getMateria(int Pos){
    return Vec[Pos];
}
public int Aprobados (){
    int i,cant;
    cant=0;
    for(i=0;i<Tam;i++){
        if(Vec[i].getDefinitiva()>=3){
            cant=cant+1;
        }
    }return cant;
}
public int Reprobados(){
   return Tam-Aprobados();
}
public float PromGeneral(){
    int i;
    float sum;
    sum=0;
    for(i=0;i<Tam;i++){
      sum=sum+ Vec[i].getDefinitiva();
    }
    if (Tam>0){
        return sum/Tam;
    }else{
        return 0;
    }
}
    public float PromAprobados(){
        int i, cant;
        float def, sum;
        sum=0;
        cant=0;
        for(i=0;i<Tam;i++){
            def=Vec[i].getDefinitiva();
            if(def>=3){
            sum=sum + def;
            cant=cant + 1;
        }
    }
        if(cant>0){
            return sum/cant;
        }
        else{
            return 0;
        }

}

}