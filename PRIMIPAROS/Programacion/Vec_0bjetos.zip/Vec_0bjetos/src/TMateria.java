
public class TMateria {
    private long Codigo;
    private String Nombre;
    private byte Semestre;
    private float Definitiva;
    
public TMateria (){
    Codigo=0;
    Nombre="";
    Semestre=0;
    Definitiva=0;
}

public void setCodigo(long Cod){
    Codigo=Cod;
}
public void setNombre(String Nom ){
    Nombre=Nom;
}
public void setSemestre(byte Sem){
 Semestre=Sem;   
}
public void setDefinitiva(float Def){
if(Def>=0 && Def<=5){
 Definitiva=Def;
}
}
public long getCodigo(){
 return Codigo;
}
public String getNombre(){
  return Nombre;
}
public byte getSemestre(){
   return Semestre;
}
public float getDefinitiva(){
  return Definitiva;
}
}