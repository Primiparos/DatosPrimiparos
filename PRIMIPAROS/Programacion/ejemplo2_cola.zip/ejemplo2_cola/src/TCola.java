public class TCola {

 private int Frente;
 private int Final;
 private int Tamaño; 
 private int Datos[];
 
 public TCola(){
  Frente=-1;
  Final=-1;
  Tamaño=0;
  Datos=null;
 }
 
 public void setTamaño(int Tam){
  Frente=0;
  Final=-1;
  Tamaño=Tam;
  if(Tam>0){
   Datos=new int[Tam];   
  }
  else{
   Datos=null;   
  }
 }
 
 public int getTamaño(){
  return Tamaño;   
 }
 
 public boolean Llena(){
  if(Final>=Tamaño-1){
   return true;   
  }   
  else{
   return false;   
  }
 }
 
 public boolean Vacia(){
  if(Final<0){
   return true;   
  }   
  else{
   return false;   
  }
 }
 
 public void Agregar(int Num){
  if(!Llena()){
   Final=Final + 1;   
   Datos[Final]=Num;
  }     
 }
 
 public void Eliminar(){
  int i;
  if(!Vacia()){
   for(i=1;i<=Final;i++){
    Datos[i-1]=Datos[i];  
   }
   Datos[Final]=0;   
   Final=Final - 1;
  }
 }
 
 public int ValorFrente(){
  return Datos[Frente];    
 }
 
 public int ValorFinal(){
  return Datos[Final];    
 }
    
}
