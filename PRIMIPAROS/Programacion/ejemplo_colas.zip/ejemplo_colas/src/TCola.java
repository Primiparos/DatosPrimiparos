public class TCola {

  private int Tamaño;//Tamaño maximo de la cola
  private int Cantidad;//Numero de elementos(nodos) actuales en la cola
  private TNodo Frente;//Representa el nodo cabeza de la lista
  private TNodo Final;//Representa el ultimo nodo agregado a la lista
  
  public TCola(){
   Tamaño=0;
   Cantidad=0;
   Frente=null;
   Final=null;   
  }
  
  public void setTamaño(int Tam){
   Tamaño=Tam;
   Cantidad=0;
   Frente=null;
   Final=null;   
  }
  
  public int getTamaño(){
   return Tamaño;   
  }
  
  public boolean Vacia(){
   if(Frente==null){//Final==null o tambien Cantidad==0
    return true;    
   }
   else{
    return false;   
   }     
  }
  
  public boolean Llena(){
   if(Cantidad>=Tamaño){
    return true;   
   }
   else{
    return false;   
   }
  }
  
  public void Agregar(TNodo Nod){
   if(!Llena()){//si la cola no esta llena
    if(Vacia()){//si la cola(lista) esta vacia
     Frente=Nod;//el nuevo nodo es ahora el primero en la cola
     Final=Nod;//el final coincide con el primer nodo de la cola
    }
    else{//la cola ya tiene elementos en espera
     Final.setSiguiete(Nod);//el ultimo actual ahgora apunta al nuevo nodo
     Final=Nod;//Actualizamos el ultimo nodo
    }
    Cantidad=Cantidad + 1;//Incrementamos el contador de nodos en 1
   }    
  }
  
  public void Eliminar(){
   if(!Vacia()){//Si la cola no esta vacia
    Frente=Frente.getSiguiente();//Movemos el primero al segundo
    Cantidad=Cantidad - 1;//Dsisminuimos en 1 el contador de nodos
   }   
  }
  
  public TNodo ValorFrente(){
   return Frente;   
  }
  
  public TNodo ValorFinal(){
   return Final;   
  }
  
  
}
