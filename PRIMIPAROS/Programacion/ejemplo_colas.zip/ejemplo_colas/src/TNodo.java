public class TNodo {
    
 private long Codigo;   
 private TNodo Siguiente;
 
 public TNodo(){
  Codigo=0;
  Siguiente=null;
 }
 
 public void setCodigo(long Cod){
  Codigo=Cod;   
 }
 
 public void setSiguiete(TNodo Sig){
  if(Sig!=this){
   Siguiente=Sig;   
  }   
 }
 
 public long getCodigo(){
  return Codigo;   
 }
 
 public TNodo getSiguiente(){
  return Siguiente;    
 }
 
 
}
