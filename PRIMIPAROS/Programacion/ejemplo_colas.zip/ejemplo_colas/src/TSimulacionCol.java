import java.util.Random;
import javax.swing.JTextArea;

public class TSimulacionCol {
 
 private byte ProbEntrada;//probablidad de que alguien llegue (1..100)
 private TCola Col;//Instancia de la clase TCola
 private Random R;
 private JTextArea Salida;
 
 public TSimulacionCol(JTextArea Sal){
  Salida=Sal;
  R=new Random(); 
  Col=new TCola();
  ProbEntrada=0;
 }
 
 public void setProEntrada(byte Prob){
  if(Prob>=10 && Prob<=80){
   ProbEntrada=Prob;   
  }   
 }
 
 public byte getProbEntrada(){
  return ProbEntrada;    
 }
 
 public TCola getCola(){
  return Col;   
 }
 
 public void Simular(){
  int Num;//numero aleatorio de 1 a 100
  TNodo Nuevo;
  String Mensaje;
  if(Col.getTamaño()>0){
   Num=R.nextInt(100) + 1;
   if(Num>=10 && Num<=ProbEntrada){
    if(!Col.Llena()){
     Nuevo=new TNodo();
     Nuevo.setCodigo(R.nextInt(50000)+10000);
     Col.Agregar(Nuevo);
     Mensaje="Nuevo Cliente: " + Nuevo.getCodigo();
     System.out.println(Mensaje);
     Salida.append(Mensaje + "\n");
    }
    else{
     Mensaje="Cola vacia"; 
     System.out.println(Mensaje);
     Salida.append(Mensaje + "\n");
    }
   }
   else//si no se agrega, entonces se eliminacion
    if(!Col.Vacia()){
     Mensaje="Se ha atendido a: " + Col.ValorFrente().getCodigo(); 
     Col.Eliminar();
     System.out.println(Mensaje);
     Salida.append(Mensaje + "\n"); 
    }
    else{
     Mensaje="Cola vacia";
     System.out.println(Mensaje);
     Salida.append(Mensaje + "\n"); 
    }
  }
 }
 
}
