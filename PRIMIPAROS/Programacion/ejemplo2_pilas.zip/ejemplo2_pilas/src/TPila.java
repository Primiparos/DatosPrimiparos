public class TPila {

 private int Tope;
 private int Tamaño;
 private String Datos[];
 
 public TPila(){
  Tope=-1;
  Tamaño=0;
  Datos=null;
 }
 
 public void setTamaño(int Tam){
  Tamaño=Tam;
  Tope=-1;
  if(Tam>0){
   Datos=new String[Tam];    
  }
  else{
   Datos=null;   
  }
 }
 
 public int getTamaño(){
  return Tamaño;   
 }
 
 public boolean Vacia(){
  if(Tope<0){   
   return true;
  }
  else{     
   return false;    
  }  
 }
 
 public boolean LLena(){
  if(Tope>=Tamaño-1){
   return true;   
  }   
  else{
   return false;   
  }
 }
 
 public void Agregar(String Dat){
  if(!LLena()){
   Tope=Tope + 1;
   Datos[Tope]=Dat;   
  }   
 }
 
 public void Eliminar(){
  if(!Vacia()){
   Datos[Tope]="";
   Tope=Tope-1;   
  }   
 }
 
 public String ValorTope(){
  return Datos[Tope];   
 }
    
}
